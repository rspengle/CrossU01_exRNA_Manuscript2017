require("DelayedArray") || stop("unable to load DelayedArray package")
DelayedArray:::.test()
